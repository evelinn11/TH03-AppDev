﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TH03_Evelin_Alim_Natadjaja
{
    internal class DataUser
    {
        public string username;
        public string password;
        public int balance = 0;
        public string rupiah;

        public DataUser(string nama, string pass)
        {
            username = nama;
            password = pass;
        }

        public void Deposit(int tambahSaldo)
        {
            balance += tambahSaldo;
        }

        public void Withdraw(int kurangSaldo)
        {
            balance -= kurangSaldo;
        }

        public string Saldo()
        {
            rupiah = string.Format(CultureInfo.CreateSpecificCulture("id-ID"), "{0:C2}", balance);
            return rupiah;
        }
    }
}
