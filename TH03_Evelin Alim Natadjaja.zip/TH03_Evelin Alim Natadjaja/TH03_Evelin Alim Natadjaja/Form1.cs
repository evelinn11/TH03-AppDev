﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03_Evelin_Alim_Natadjaja
{
    public partial class Form1 : Form
    {
        List<DataUser> akunUser = new List<DataUser>();
        int indexUser = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void btn_RegisterLV_Click(object sender, EventArgs e)
        {
            panelLoginView.Visible = false;
            panelRegisterView.Visible = true;
        }

        private void btn_RegisterRV_Click(object sender, EventArgs e)
        {
            //cek textbox belum terisi
            bool notFilled = false;
            if (tB_UsernameRV.Text == string.Empty || tB_PasswordRV.Text == string.Empty)
            {
                notFilled = true;
            }
            //cek username kembar
            bool used = false;
            for (int i = 0; i < akunUser.Count(); i++)
            {
                if (tB_UsernameRV.Text == akunUser[i].username)
                {
                    used = true;
                }
            }
            //hasil cek
            if (notFilled)
            {
                MessageBox.Show("Username and Password Must Be Filled");
                tB_UsernameRV.Clear();
                tB_PasswordRV.Clear();
            }
            else if (used)
            {
                MessageBox.Show("Username Has Been Used");
                tB_UsernameRV.Clear();
                tB_PasswordRV.Clear();
            }
            else
            {
                DataUser userBaru = new DataUser(tB_UsernameRV.Text, tB_PasswordRV.Text);
                akunUser.Add(userBaru);
                MessageBox.Show("Register Successful");
                tB_UsernameRV.Clear();
                tB_PasswordRV.Clear();
                panelLoginView.Visible = true;
                panelRegisterView.Visible = false;
            }
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            //cek username apa ada di list
            bool available = false;
            for (int i = 0; i < akunUser.Count(); i++)
            {
                if (tB_UsernameLV.Text == akunUser[i].username)
                {
                    available = true;
                    indexUser = i;
                }
            }
            //hasil cek
            if (available)
            {
                if (tB_PasswordLV.Text == akunUser[indexUser].password)
                {
                    MessageBox.Show("Login Successful");
                    panelLoginView.Visible = false;
                    panelMainView.Visible = true;
                }
                else
                {
                    MessageBox.Show("Username and Password Not Found!");
                }
            }
            else
            {
                MessageBox.Show("Username and Password Not Found!");
            }
            tB_UsernameLV.Clear();
            tB_PasswordLV.Clear();
        }

        private void btn_LogOut_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Log Out Berhasil");
            panelMainView.Visible = false;
            panelLoginView.Visible = true;
        }

        private void btn_Deposit_Click(object sender, EventArgs e)
        {
            panelDepositView.Visible = true;
        }

        private void btn_DepositDV_Click(object sender, EventArgs e)
        {
            //cek textbox
            int jumlahDeposit = Convert.ToInt32(tB_InputDeposit.Text);
            if (jumlahDeposit > 0)
            {
                akunUser[indexUser].Deposit(jumlahDeposit);
                lb_Saldo.Text = akunUser[indexUser].Saldo();
                lb_SaldoWV.Text = akunUser[indexUser].Saldo();
                MessageBox.Show("Successfully Add Deposit");               
            }
            else
            {
                MessageBox.Show("Deposit Amount Can't Be Less Than 1");
            }
            tB_InputDeposit.Clear();
            panelDepositView.Visible = false;
        }

        private void btn_Withdraw_Click(object sender, EventArgs e)
        {
            panelWithdrawView.Visible = true;
        }

        private void btn_WithdrawWV_Click(object sender, EventArgs e)
        {
            int jumlahWithdraw = Convert.ToInt32(tB_InputWithdraw.Text);
            if (jumlahWithdraw > akunUser[indexUser].balance)
            {
                MessageBox.Show("Withdraw Failed. Not Enough Balance");
            }
            else if (jumlahWithdraw <= 0)
            {
                MessageBox.Show("Withdraw Amount Can't Be Less Than 1");
            }
            else
            {
                MessageBox.Show("Successfully Withdraw");
                akunUser[indexUser].Withdraw(jumlahWithdraw);
                lb_Saldo.Text = akunUser[indexUser].Saldo();
                lb_SaldoWV.Text = akunUser[indexUser].Saldo();
            }
            tB_InputWithdraw.Clear();
            panelWithdrawView.Visible = false;
        }

        private void panelMainView_VisibleChanged(object sender, EventArgs e)
        {
            lb_Saldo.Text = akunUser[indexUser].Saldo();
            lb_SaldoWV.Text = akunUser[indexUser].Saldo();
        }
    }
}
