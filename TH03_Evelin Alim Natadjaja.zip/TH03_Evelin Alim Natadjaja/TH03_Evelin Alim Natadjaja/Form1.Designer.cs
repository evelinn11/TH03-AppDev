﻿namespace TH03_Evelin_Alim_Natadjaja
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_UCBankLV = new System.Windows.Forms.Label();
            this.lb_PasswordLV = new System.Windows.Forms.Label();
            this.lb_UsernameLV = new System.Windows.Forms.Label();
            this.tB_UsernameLV = new System.Windows.Forms.TextBox();
            this.tB_PasswordLV = new System.Windows.Forms.TextBox();
            this.btn_Login = new System.Windows.Forms.Button();
            this.panelLoginView = new System.Windows.Forms.Panel();
            this.btn_RegisterLV = new System.Windows.Forms.Button();
            this.panelRegisterView = new System.Windows.Forms.Panel();
            this.btn_RegisterRV = new System.Windows.Forms.Button();
            this.tB_PasswordRV = new System.Windows.Forms.TextBox();
            this.tB_UsernameRV = new System.Windows.Forms.TextBox();
            this.lb_UsernameRV = new System.Windows.Forms.Label();
            this.lb_PasswordRV = new System.Windows.Forms.Label();
            this.lb_UCBankRV = new System.Windows.Forms.Label();
            this.panelMainView = new System.Windows.Forms.Panel();
            this.btn_Deposit = new System.Windows.Forms.Button();
            this.btn_Withdraw = new System.Windows.Forms.Button();
            this.btn_LogOut = new System.Windows.Forms.Button();
            this.lb_Balance = new System.Windows.Forms.Label();
            this.lb_Saldo = new System.Windows.Forms.Label();
            this.lb_UCBankMV = new System.Windows.Forms.Label();
            this.panelDepositView = new System.Windows.Forms.Panel();
            this.btn_DepositDV = new System.Windows.Forms.Button();
            this.lb_InputDeposit = new System.Windows.Forms.Label();
            this.tB_InputDeposit = new System.Windows.Forms.TextBox();
            this.panelWithdrawView = new System.Windows.Forms.Panel();
            this.lb_BalanceWV = new System.Windows.Forms.Label();
            this.lb_SaldoWV = new System.Windows.Forms.Label();
            this.btn_WithdrawWV = new System.Windows.Forms.Button();
            this.lb_InputWithdraw = new System.Windows.Forms.Label();
            this.tB_InputWithdraw = new System.Windows.Forms.TextBox();
            this.panelLoginView.SuspendLayout();
            this.panelRegisterView.SuspendLayout();
            this.panelMainView.SuspendLayout();
            this.panelDepositView.SuspendLayout();
            this.panelWithdrawView.SuspendLayout();
            this.SuspendLayout();
            // 
            // lb_UCBankLV
            // 
            this.lb_UCBankLV.AutoSize = true;
            this.lb_UCBankLV.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_UCBankLV.Location = new System.Drawing.Point(101, 54);
            this.lb_UCBankLV.Name = "lb_UCBankLV";
            this.lb_UCBankLV.Size = new System.Drawing.Size(130, 31);
            this.lb_UCBankLV.TabIndex = 0;
            this.lb_UCBankLV.Text = "UC Bank";
            // 
            // lb_PasswordLV
            // 
            this.lb_PasswordLV.AutoSize = true;
            this.lb_PasswordLV.Location = new System.Drawing.Point(74, 168);
            this.lb_PasswordLV.Name = "lb_PasswordLV";
            this.lb_PasswordLV.Size = new System.Drawing.Size(53, 13);
            this.lb_PasswordLV.TabIndex = 1;
            this.lb_PasswordLV.Text = "Password";
            // 
            // lb_UsernameLV
            // 
            this.lb_UsernameLV.AutoSize = true;
            this.lb_UsernameLV.Location = new System.Drawing.Point(74, 140);
            this.lb_UsernameLV.Name = "lb_UsernameLV";
            this.lb_UsernameLV.Size = new System.Drawing.Size(55, 13);
            this.lb_UsernameLV.TabIndex = 2;
            this.lb_UsernameLV.Text = "Username";
            // 
            // tB_UsernameLV
            // 
            this.tB_UsernameLV.Location = new System.Drawing.Point(135, 137);
            this.tB_UsernameLV.Name = "tB_UsernameLV";
            this.tB_UsernameLV.Size = new System.Drawing.Size(122, 20);
            this.tB_UsernameLV.TabIndex = 3;
            // 
            // tB_PasswordLV
            // 
            this.tB_PasswordLV.Location = new System.Drawing.Point(135, 163);
            this.tB_PasswordLV.Name = "tB_PasswordLV";
            this.tB_PasswordLV.Size = new System.Drawing.Size(122, 20);
            this.tB_PasswordLV.TabIndex = 4;
            // 
            // btn_Login
            // 
            this.btn_Login.Location = new System.Drawing.Point(117, 203);
            this.btn_Login.Name = "btn_Login";
            this.btn_Login.Size = new System.Drawing.Size(94, 27);
            this.btn_Login.TabIndex = 5;
            this.btn_Login.Text = "Login";
            this.btn_Login.UseVisualStyleBackColor = true;
            this.btn_Login.Click += new System.EventHandler(this.btn_Login_Click);
            // 
            // panelLoginView
            // 
            this.panelLoginView.Controls.Add(this.btn_RegisterLV);
            this.panelLoginView.Controls.Add(this.btn_Login);
            this.panelLoginView.Controls.Add(this.tB_PasswordLV);
            this.panelLoginView.Controls.Add(this.tB_UsernameLV);
            this.panelLoginView.Controls.Add(this.lb_UsernameLV);
            this.panelLoginView.Controls.Add(this.lb_PasswordLV);
            this.panelLoginView.Controls.Add(this.lb_UCBankLV);
            this.panelLoginView.Location = new System.Drawing.Point(1, 2);
            this.panelLoginView.Name = "panelLoginView";
            this.panelLoginView.Size = new System.Drawing.Size(336, 303);
            this.panelLoginView.TabIndex = 7;
            // 
            // btn_RegisterLV
            // 
            this.btn_RegisterLV.Location = new System.Drawing.Point(117, 236);
            this.btn_RegisterLV.Name = "btn_RegisterLV";
            this.btn_RegisterLV.Size = new System.Drawing.Size(94, 27);
            this.btn_RegisterLV.TabIndex = 6;
            this.btn_RegisterLV.Text = "Register";
            this.btn_RegisterLV.UseVisualStyleBackColor = true;
            this.btn_RegisterLV.Click += new System.EventHandler(this.btn_RegisterLV_Click);
            // 
            // panelRegisterView
            // 
            this.panelRegisterView.Controls.Add(this.btn_RegisterRV);
            this.panelRegisterView.Controls.Add(this.tB_PasswordRV);
            this.panelRegisterView.Controls.Add(this.tB_UsernameRV);
            this.panelRegisterView.Controls.Add(this.lb_UsernameRV);
            this.panelRegisterView.Controls.Add(this.lb_PasswordRV);
            this.panelRegisterView.Controls.Add(this.lb_UCBankRV);
            this.panelRegisterView.Location = new System.Drawing.Point(1, 2);
            this.panelRegisterView.Name = "panelRegisterView";
            this.panelRegisterView.Size = new System.Drawing.Size(336, 294);
            this.panelRegisterView.TabIndex = 8;
            this.panelRegisterView.Visible = false;
            // 
            // btn_RegisterRV
            // 
            this.btn_RegisterRV.Location = new System.Drawing.Point(118, 204);
            this.btn_RegisterRV.Name = "btn_RegisterRV";
            this.btn_RegisterRV.Size = new System.Drawing.Size(94, 27);
            this.btn_RegisterRV.TabIndex = 6;
            this.btn_RegisterRV.Text = "Register";
            this.btn_RegisterRV.UseVisualStyleBackColor = true;
            this.btn_RegisterRV.Click += new System.EventHandler(this.btn_RegisterRV_Click);
            // 
            // tB_PasswordRV
            // 
            this.tB_PasswordRV.Location = new System.Drawing.Point(135, 163);
            this.tB_PasswordRV.Name = "tB_PasswordRV";
            this.tB_PasswordRV.Size = new System.Drawing.Size(122, 20);
            this.tB_PasswordRV.TabIndex = 4;
            // 
            // tB_UsernameRV
            // 
            this.tB_UsernameRV.Location = new System.Drawing.Point(135, 137);
            this.tB_UsernameRV.Name = "tB_UsernameRV";
            this.tB_UsernameRV.Size = new System.Drawing.Size(122, 20);
            this.tB_UsernameRV.TabIndex = 3;
            // 
            // lb_UsernameRV
            // 
            this.lb_UsernameRV.AutoSize = true;
            this.lb_UsernameRV.Location = new System.Drawing.Point(74, 140);
            this.lb_UsernameRV.Name = "lb_UsernameRV";
            this.lb_UsernameRV.Size = new System.Drawing.Size(55, 13);
            this.lb_UsernameRV.TabIndex = 2;
            this.lb_UsernameRV.Text = "Username";
            // 
            // lb_PasswordRV
            // 
            this.lb_PasswordRV.AutoSize = true;
            this.lb_PasswordRV.Location = new System.Drawing.Point(74, 168);
            this.lb_PasswordRV.Name = "lb_PasswordRV";
            this.lb_PasswordRV.Size = new System.Drawing.Size(53, 13);
            this.lb_PasswordRV.TabIndex = 1;
            this.lb_PasswordRV.Text = "Password";
            // 
            // lb_UCBankRV
            // 
            this.lb_UCBankRV.AutoSize = true;
            this.lb_UCBankRV.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_UCBankRV.Location = new System.Drawing.Point(101, 54);
            this.lb_UCBankRV.Name = "lb_UCBankRV";
            this.lb_UCBankRV.Size = new System.Drawing.Size(130, 31);
            this.lb_UCBankRV.TabIndex = 0;
            this.lb_UCBankRV.Text = "UC Bank";
            // 
            // panelMainView
            // 
            this.panelMainView.Controls.Add(this.btn_Deposit);
            this.panelMainView.Controls.Add(this.btn_Withdraw);
            this.panelMainView.Controls.Add(this.btn_LogOut);
            this.panelMainView.Controls.Add(this.lb_Balance);
            this.panelMainView.Controls.Add(this.lb_Saldo);
            this.panelMainView.Controls.Add(this.lb_UCBankMV);
            this.panelMainView.Location = new System.Drawing.Point(1, 2);
            this.panelMainView.Name = "panelMainView";
            this.panelMainView.Size = new System.Drawing.Size(336, 306);
            this.panelMainView.TabIndex = 8;
            this.panelMainView.Visible = false;
            this.panelMainView.VisibleChanged += new System.EventHandler(this.panelMainView_VisibleChanged);
            // 
            // btn_Deposit
            // 
            this.btn_Deposit.Location = new System.Drawing.Point(117, 189);
            this.btn_Deposit.Name = "btn_Deposit";
            this.btn_Deposit.Size = new System.Drawing.Size(94, 27);
            this.btn_Deposit.TabIndex = 7;
            this.btn_Deposit.Text = "Deposit";
            this.btn_Deposit.UseVisualStyleBackColor = true;
            this.btn_Deposit.Click += new System.EventHandler(this.btn_Deposit_Click);
            // 
            // btn_Withdraw
            // 
            this.btn_Withdraw.Location = new System.Drawing.Point(117, 222);
            this.btn_Withdraw.Name = "btn_Withdraw";
            this.btn_Withdraw.Size = new System.Drawing.Size(94, 27);
            this.btn_Withdraw.TabIndex = 6;
            this.btn_Withdraw.Text = "Withdraw";
            this.btn_Withdraw.UseVisualStyleBackColor = true;
            this.btn_Withdraw.Click += new System.EventHandler(this.btn_Withdraw_Click);
            // 
            // btn_LogOut
            // 
            this.btn_LogOut.Location = new System.Drawing.Point(220, 100);
            this.btn_LogOut.Name = "btn_LogOut";
            this.btn_LogOut.Size = new System.Drawing.Size(86, 27);
            this.btn_LogOut.TabIndex = 5;
            this.btn_LogOut.Text = "Log Out";
            this.btn_LogOut.UseVisualStyleBackColor = true;
            this.btn_LogOut.Click += new System.EventHandler(this.btn_LogOut_Click);
            // 
            // lb_Balance
            // 
            this.lb_Balance.AutoSize = true;
            this.lb_Balance.Location = new System.Drawing.Point(74, 155);
            this.lb_Balance.Name = "lb_Balance";
            this.lb_Balance.Size = new System.Drawing.Size(46, 13);
            this.lb_Balance.TabIndex = 2;
            this.lb_Balance.Text = "Balance";
            // 
            // lb_Saldo
            // 
            this.lb_Saldo.AutoSize = true;
            this.lb_Saldo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Saldo.Location = new System.Drawing.Point(131, 150);
            this.lb_Saldo.Name = "lb_Saldo";
            this.lb_Saldo.Size = new System.Drawing.Size(18, 20);
            this.lb_Saldo.TabIndex = 1;
            this.lb_Saldo.Text = "0";
            // 
            // lb_UCBankMV
            // 
            this.lb_UCBankMV.AutoSize = true;
            this.lb_UCBankMV.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_UCBankMV.Location = new System.Drawing.Point(101, 54);
            this.lb_UCBankMV.Name = "lb_UCBankMV";
            this.lb_UCBankMV.Size = new System.Drawing.Size(130, 31);
            this.lb_UCBankMV.TabIndex = 0;
            this.lb_UCBankMV.Text = "UC Bank";
            // 
            // panelDepositView
            // 
            this.panelDepositView.Controls.Add(this.btn_DepositDV);
            this.panelDepositView.Controls.Add(this.lb_InputDeposit);
            this.panelDepositView.Controls.Add(this.tB_InputDeposit);
            this.panelDepositView.Location = new System.Drawing.Point(1, 135);
            this.panelDepositView.Name = "panelDepositView";
            this.panelDepositView.Size = new System.Drawing.Size(336, 176);
            this.panelDepositView.TabIndex = 9;
            this.panelDepositView.Visible = false;
            // 
            // btn_DepositDV
            // 
            this.btn_DepositDV.Location = new System.Drawing.Point(117, 91);
            this.btn_DepositDV.Name = "btn_DepositDV";
            this.btn_DepositDV.Size = new System.Drawing.Size(94, 27);
            this.btn_DepositDV.TabIndex = 7;
            this.btn_DepositDV.Text = "Deposit";
            this.btn_DepositDV.UseVisualStyleBackColor = true;
            this.btn_DepositDV.Click += new System.EventHandler(this.btn_DepositDV_Click);
            // 
            // lb_InputDeposit
            // 
            this.lb_InputDeposit.AutoSize = true;
            this.lb_InputDeposit.Location = new System.Drawing.Point(114, 18);
            this.lb_InputDeposit.Name = "lb_InputDeposit";
            this.lb_InputDeposit.Size = new System.Drawing.Size(112, 13);
            this.lb_InputDeposit.TabIndex = 7;
            this.lb_InputDeposit.Text = "Input Deposit Amount:";
            // 
            // tB_InputDeposit
            // 
            this.tB_InputDeposit.Location = new System.Drawing.Point(104, 51);
            this.tB_InputDeposit.Name = "tB_InputDeposit";
            this.tB_InputDeposit.Size = new System.Drawing.Size(129, 20);
            this.tB_InputDeposit.TabIndex = 7;
            // 
            // panelWithdrawView
            // 
            this.panelWithdrawView.Controls.Add(this.lb_BalanceWV);
            this.panelWithdrawView.Controls.Add(this.lb_SaldoWV);
            this.panelWithdrawView.Controls.Add(this.btn_WithdrawWV);
            this.panelWithdrawView.Controls.Add(this.lb_InputWithdraw);
            this.panelWithdrawView.Controls.Add(this.tB_InputWithdraw);
            this.panelWithdrawView.Location = new System.Drawing.Point(1, 135);
            this.panelWithdrawView.Name = "panelWithdrawView";
            this.panelWithdrawView.Size = new System.Drawing.Size(336, 176);
            this.panelWithdrawView.TabIndex = 10;
            this.panelWithdrawView.Visible = false;
            // 
            // lb_BalanceWV
            // 
            this.lb_BalanceWV.AutoSize = true;
            this.lb_BalanceWV.Location = new System.Drawing.Point(84, 22);
            this.lb_BalanceWV.Name = "lb_BalanceWV";
            this.lb_BalanceWV.Size = new System.Drawing.Size(46, 13);
            this.lb_BalanceWV.TabIndex = 9;
            this.lb_BalanceWV.Text = "Balance";
            // 
            // lb_SaldoWV
            // 
            this.lb_SaldoWV.AutoSize = true;
            this.lb_SaldoWV.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_SaldoWV.Location = new System.Drawing.Point(138, 18);
            this.lb_SaldoWV.Name = "lb_SaldoWV";
            this.lb_SaldoWV.Size = new System.Drawing.Size(18, 20);
            this.lb_SaldoWV.TabIndex = 8;
            this.lb_SaldoWV.Text = "0";
            // 
            // btn_WithdrawWV
            // 
            this.btn_WithdrawWV.Location = new System.Drawing.Point(118, 119);
            this.btn_WithdrawWV.Name = "btn_WithdrawWV";
            this.btn_WithdrawWV.Size = new System.Drawing.Size(94, 27);
            this.btn_WithdrawWV.TabIndex = 7;
            this.btn_WithdrawWV.Text = "Withdraw";
            this.btn_WithdrawWV.UseVisualStyleBackColor = true;
            this.btn_WithdrawWV.Click += new System.EventHandler(this.btn_WithdrawWV_Click);
            // 
            // lb_InputWithdraw
            // 
            this.lb_InputWithdraw.AutoSize = true;
            this.lb_InputWithdraw.Location = new System.Drawing.Point(103, 61);
            this.lb_InputWithdraw.Name = "lb_InputWithdraw";
            this.lb_InputWithdraw.Size = new System.Drawing.Size(129, 13);
            this.lb_InputWithdraw.TabIndex = 7;
            this.lb_InputWithdraw.Text = "Input Withdrawal Amount:";
            // 
            // tB_InputWithdraw
            // 
            this.tB_InputWithdraw.Location = new System.Drawing.Point(103, 86);
            this.tB_InputWithdraw.Name = "tB_InputWithdraw";
            this.tB_InputWithdraw.Size = new System.Drawing.Size(129, 20);
            this.tB_InputWithdraw.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(338, 304);
            this.Controls.Add(this.panelLoginView);
            this.Controls.Add(this.panelRegisterView);
            this.Controls.Add(this.panelWithdrawView);
            this.Controls.Add(this.panelDepositView);
            this.Controls.Add(this.panelMainView);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panelLoginView.ResumeLayout(false);
            this.panelLoginView.PerformLayout();
            this.panelRegisterView.ResumeLayout(false);
            this.panelRegisterView.PerformLayout();
            this.panelMainView.ResumeLayout(false);
            this.panelMainView.PerformLayout();
            this.panelDepositView.ResumeLayout(false);
            this.panelDepositView.PerformLayout();
            this.panelWithdrawView.ResumeLayout(false);
            this.panelWithdrawView.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lb_UCBankLV;
        private System.Windows.Forms.Label lb_PasswordLV;
        private System.Windows.Forms.Label lb_UsernameLV;
        private System.Windows.Forms.TextBox tB_UsernameLV;
        private System.Windows.Forms.TextBox tB_PasswordLV;
        private System.Windows.Forms.Button btn_Login;
        private System.Windows.Forms.Panel panelLoginView;
        private System.Windows.Forms.Button btn_RegisterLV;
        private System.Windows.Forms.Panel panelRegisterView;
        private System.Windows.Forms.Button btn_RegisterRV;
        private System.Windows.Forms.TextBox tB_PasswordRV;
        private System.Windows.Forms.TextBox tB_UsernameRV;
        private System.Windows.Forms.Label lb_UsernameRV;
        private System.Windows.Forms.Label lb_PasswordRV;
        private System.Windows.Forms.Label lb_UCBankRV;
        private System.Windows.Forms.Panel panelMainView;
        private System.Windows.Forms.Button btn_Withdraw;
        private System.Windows.Forms.Button btn_LogOut;
        private System.Windows.Forms.Label lb_Balance;
        private System.Windows.Forms.Label lb_Saldo;
        private System.Windows.Forms.Label lb_UCBankMV;
        private System.Windows.Forms.Button btn_Deposit;
        private System.Windows.Forms.Panel panelDepositView;
        private System.Windows.Forms.Label lb_InputDeposit;
        private System.Windows.Forms.TextBox tB_InputDeposit;
        private System.Windows.Forms.Button btn_DepositDV;
        private System.Windows.Forms.Panel panelWithdrawView;
        private System.Windows.Forms.Button btn_WithdrawWV;
        private System.Windows.Forms.Label lb_InputWithdraw;
        private System.Windows.Forms.TextBox tB_InputWithdraw;
        private System.Windows.Forms.Label lb_BalanceWV;
        private System.Windows.Forms.Label lb_SaldoWV;
    }
}

